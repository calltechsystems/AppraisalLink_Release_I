const Filtering = () => {
  return (
    <select className="selectpicker show-tick form-select c_select">
      <option>Active</option>
      <option>Inactive</option>
      {/* <option>Last 6 months</option>
      <option>Last 1 year</option> */}
    </select>
  );
};

export default Filtering;
