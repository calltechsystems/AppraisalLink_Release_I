const Filtering = () => {
    return (
      <select className="selectpicker show-tick form-select c_select">
        <option value={"Monthly"}>Monthly</option>
        <option value={"Weekly"}>Weekly</option>
        <option value={"Yearly"}>Yearly</option>
      </select>
    );
  };
  
  export default Filtering;