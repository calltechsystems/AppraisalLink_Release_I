const SearchBox = ({ setSearchInput }) => {
  return (
    <form className="d-flex flex-wrap align-items-center my-2">
      <input
        className="form-control mr-sm-2"
        type="search"
        placeholder="Search By Order ID, City, State, Postal Code"
        aria-label="Search"
        onChange={(e) => setSearchInput(e.target.value)}
      />
      <button className=" my-2 my-sm-0" disabled>
        <span className="flaticon-magnifying-glass"></span>
      </button>
    </form>
  );
};

export default SearchBox;
